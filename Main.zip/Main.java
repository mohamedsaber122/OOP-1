class Main {
  public static void main(String[] args) {
    Emp e1 = new Emp( 199544 ,  "Mohamed Saber" ,50000 ); 

        System.out.println(e1.displayInfo()); 

  }
}